export default {
    mapsKey: 'AIzaSyBeOXOZqlVVZgu-NdCIMGysieC4RWDjX6A'
}