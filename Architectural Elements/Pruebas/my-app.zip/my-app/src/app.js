import React from 'react';
import {
  LoggedIn, LoggedOut,
  Value, Image, List
} from '@solid/react';
import  Dashboard  from './components/Dashboard';
import MapContainer from './components/MapContainer';
import PopUpPod from './components/PopUpPod';

export default function App() {
  return (
    <div>
      <header>
        <h1>Prueba 1 / React-Solid
        </h1>
      </header>
      <main>
        <LoggedIn>
          <p>Welcome back, <Value src="user.name"/>.</p>
          <Image src="user.image" defaultSrc="logo192.png" className="pic"/>
          <p> <Value src="user.email"/>.</p>
          <h2>Friends</h2>
          <List src="user.friends"/>
          <Dashboard/>
          <MapContainer/>
        </LoggedIn>
        <LoggedOut>
            <PopUpPod/>
            <p>You are logged out.</p>
        </LoggedOut>
      </main>
      <footer>
      </footer>
    </div>
  );
}